import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import {MatDialog, MatDialogConfig} from "@angular/material";
import { AddDialogComponent } from '../add-dialog/add-dialog.component';

export interface Customer {

  firstname: string;
  lastname: string;
  address: string;
  state: string;
  country: string;
  order_total: string;
}


@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  title = "Customers";
  // customers: any;
  private customers: Customer[];
  private url = '/api/customers';

  constructor(private http: HttpClient, private dialog: MatDialog) { }

  ngOnInit() {
    this.getCustomers().subscribe(
      data => { this.customers = data; console.log(data) }
    )
  }

  getCustomers() {

    return this.http.get<Customer[]>(this.url)
  }

  openDialog(){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
  
  //   dialogConfig.position = {
  //     'top': '0',
  //     'left' : '0',

  // };

    dialogConfig.data={
      id:1,
      title: 'Angular'
    };

    this.dialog.open(AddDialogComponent, dialogConfig);

    const dialogRef = this.dialog.open(AddDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(
       data => console.log("AddDialog output:", data) 
    );

  }

}
