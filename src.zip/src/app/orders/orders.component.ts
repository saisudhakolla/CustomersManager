import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

export interface Order {

  name: string;
  item1: string;
  item2: string;
  cost1: string;
  cost2: string;
  total: string;

}

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  title = "Orders";
  private orders: Order[];
  private url = '/api/orders';

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.getOrders().subscribe(
      data => { this.orders = data; console.log(data) }
    )
  }
  getOrders() {

    return this.http.get<Order[]>(this.url)
  }

}
