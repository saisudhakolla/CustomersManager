export const customers = [
    {
      firstname: "Fed",
      lastname: "John",
      address: "234 John Street Ave",
      state: "Pheonix",
      country: "USA",
      order_total: "$900"
    },

    {
      firstname: "Sam",
      lastname: "Finch",
      address: "134 Mark Street Ave",
      state: "Ariziona",
      country: "USA",
      order_total: "$690"
    },

     {
      firstname: "Rick",
      lastname: "Mickalle",
      address: "180 Rox Street Ave",
      state: "Ariziona",
      country: "USA",
      order_total: "$1090"
    }
  ];