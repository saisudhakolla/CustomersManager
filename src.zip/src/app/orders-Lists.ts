export const orders = [

    {
          name: "Fed John",
          item1: "Shoes",
          item2: "Basketball",
          cost1: "$500",
          cost2: "$200",
          total: "$900" 
      },
      {
          name: "Sam Finch",
          item1: "Frisbe",
          item2: "Footballs",
          cost1: "$500",
          cost2: "$190",
          total: "$690"
  
      }
  ]