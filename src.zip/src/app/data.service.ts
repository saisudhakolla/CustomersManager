import { Injectable } from '@angular/core';
import { InMemoryDbService } from "angular-in-memory-web-api";

import { customers } from './customers-List';
import { orders } from './orders-Lists';

@Injectable({
  providedIn: 'root'
})
export class DataService implements InMemoryDbService {

  createDb() {

    
    return { customers, orders };
  }
}
